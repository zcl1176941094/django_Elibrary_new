<template>
    <div class="mmfooter">
        <p>foot</p>

    </div>


    
</template>


<script>
	export default{
		name:'adfooter',
        data(){
            return {}
        },
        methods:{

        }
    }
</script>


<style scoped="scoped">
.mmfooter{ 
    height: auto;
}


</style>